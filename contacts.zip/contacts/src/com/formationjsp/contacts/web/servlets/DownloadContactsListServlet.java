package com.formationjsp.contacts.web.servlets;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.formationjsp.contacts.Contact;
import com.formationjsp.contacts.listeners.ContactsContextListener;

/**
 * Servlet implementation class ContactsListServlet
 */
public class DownloadContactsListServlet extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 8630079628367657867L;



	/**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadContactsListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuffer result = new StringBuffer();
		List<Contact> contactList = (List<Contact>)getServletContext().getAttribute(ContactsContextListener.ATTNAME_CONTACT_LIST);
		
		for(int i = 0; i < contactList.size(); ++i){
			Contact contact = contactList.get(i);
			
			result.append(contact.getName() + "\t" + contact.getFirstName() + "\t" + contact.getEmail());
			if(i <= contactList.size()-1){
				result.append("\n");
			}
		}
		
		ByteArrayInputStream is = new ByteArrayInputStream(result.toString().getBytes());

		response.setContentType("application/force-download"); 
		response.setHeader("Content-Disposition","attachment; filename=\"contacts.txt\"");
		
		OutputStream os = response.getOutputStream();
		int read = 0;
		byte[] bytes = new byte[1024];
		while ((read = is.read(bytes)) != -1) {
			os.write(bytes, 0, read);
		}
		os.flush();
		os.close();
			
		
		}

}
