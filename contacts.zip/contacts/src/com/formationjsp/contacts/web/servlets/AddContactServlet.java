package com.formationjsp.contacts.web.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.formationjsp.contacts.Contact;
import com.formationjsp.contacts.listeners.ContactsContextListener;

/**
 * Servlet implementation class AddContactServlet
 */
public class AddContactServlet extends HttpServlet {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -7255856289973680231L;



	/**
     * @see HttpServlet#HttpServlet()
     */
    public AddContactServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String surname = request.getParameter("surname");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		if(surname != null && name != null && email != null){
			Contact contact = new Contact(name, surname, email);
			List<Contact> contactList = (List<Contact>)getServletContext().getAttribute(ContactsContextListener.ATTNAME_CONTACT_LIST);
			contactList.add(contact);
		}
		response.sendRedirect("/contacts/list");
	}

}
