package com.formationjsp.contacts.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.formationjsp.contacts.Contact;
import com.formationjsp.contacts.listeners.ContactsContextListener;

/**
 * Servlet implementation class ContactsListServlet
 */
public class ContactsListServlet extends HttpServlet {
       
    /**
	 * 
	 */
	private static final long serialVersionUID = 8630079628367657867L;



	/**
     * @see HttpServlet#HttpServlet()
     */
    public ContactsListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		StringBuffer result = new StringBuffer();
		
		List<Contact> contactList = (List<Contact>)getServletContext().getAttribute(ContactsContextListener.ATTNAME_CONTACT_LIST);
				
		result.append("<html><head>");
		result.append("<title>Liste des contacts</title>");
		result.append("</head><body>");
		result.append("<H1>Liste des contacts</H1>");
		
		for(Contact contact : contactList){
			result.append(contact.toString() + "<br>");
		}
		result.append("<form method=\"POST\" action=\"add\">");
		result.append("surname : <input type=\"text\" name=\"surname\"/>");
		result.append("name : <input type=\"text\" name=\"name\"/>");
		result.append("email adress : <input type=\"text\" name=\"email\"/>");
		result.append("<input type=\"submit\" value=\"ajouter\"/>");
		result.append("</form>"); 
		
		result.append("<form method=\"POST\" action=\"download\">");
		result.append("<input type=\"submit\" value=\"download contact list\"/>");
		result.append("</form>"); 
		
		
		result.append("</body></html>");
		PrintWriter out = response.getWriter();
		out.println(result.toString());
	}

}
