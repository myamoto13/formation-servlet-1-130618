package com.formationjsp.contacts.filter;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;


public class PerformancesTrackingFilter implements Filter {

	private static Logger logger = Logger.getLogger(PerformancesTrackingFilter.class.getName());
	
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain filterChain) throws IOException, ServletException {
		Date date = new Date();
		
		String performanceLog = "performance log : " + date + " : " + ((HttpServletRequest)arg0).getRequestURI();
		filterChain.doFilter(arg0, arg1);
		
		performanceLog += " (" + (new Date().getTime() - date.getTime()) + " ms)";
	
		logger.info(performanceLog);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
