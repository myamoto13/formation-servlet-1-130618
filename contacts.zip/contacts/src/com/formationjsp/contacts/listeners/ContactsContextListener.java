
package com.formationjsp.contacts.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.formationjsp.contacts.services.ContactServices;


public class ContactsContextListener implements ServletContextListener {

	public static final String ATTNAME_CONTACT_LIST = "contactList";
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	public void contextInitialized(ServletContextEvent arg0) {
		ContactServices contactServices = new ContactServices();
		arg0.getServletContext().setAttribute(ATTNAME_CONTACT_LIST, contactServices.list(arg0.getServletContext()));
	}

}