package com.formationjsp.contacts;

public class Contact {

	private String name;
	private String firstName;
	private String email;
	
	public Contact(){}
	
	public Contact(String name, String firstName, String email) {
		super();
		this.name = name;
		this.firstName = firstName;
		this.email = email;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Contact [name=" + name + ", firstName=" + firstName
				+ ", email=" + email + "]";
	}
	
}
