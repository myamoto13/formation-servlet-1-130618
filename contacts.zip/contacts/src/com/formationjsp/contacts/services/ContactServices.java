package com.formationjsp.contacts.services;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContext;

import com.formationjsp.contacts.Contact;

public class ContactServices {

	private static Logger logger = Logger.getLogger(ContactServices.class.getName());

	public List<Contact> list(ServletContext servletContext){

		List<Contact> result = new ArrayList<Contact>();
		String contactsString = servletContext.getInitParameter("contacts");

		result = getContactListTokenizer(contactsString);
		return result;
	}

	private List<Contact> getContactListTokenizer(String contactsString) {
		List<Contact> result = null;
		if(contactsString != null){
			result = new ArrayList<Contact>();
			StringTokenizer contactTknz = new StringTokenizer(contactsString, "#");
			while(contactTknz.hasMoreTokens()){
				String contactString = contactTknz.nextToken();
				StringTokenizer attributeTknz = new StringTokenizer(contactString, ";");
				
				
				if(attributeTknz.countTokens() == 3){
					Contact contact = new Contact();
					contact.setName(attributeTknz.nextToken());
					contact.setFirstName(attributeTknz.nextToken());
					contact.setEmail(attributeTknz.nextToken());
					result.add(contact);
				}else{
					logger.log(Level.SEVERE, "Contact malform� : " + contactString);
				}
			}
		}
		return result;
	}

	private List<Contact> getContactList(String contactsString) {
		List<Contact> result = null;
		if(contactsString != null){
			String[] contactTab = contactsString.split("#");
			if(contactTab != null){
				result = new ArrayList<Contact>();
				for (String contactString : contactTab) {
					String[] contactFieldList = contactString.split(";");
					if(contactFieldList != null && contactFieldList.length == 3){
						Contact contact = new Contact();
						contact.setName(contactFieldList[0]);
						contact.setFirstName(contactFieldList[1]);
						contact.setEmail(contactFieldList[2]);
						result.add(contact);
					}else{
						logger.log(Level.SEVERE, "Contact malform� : " + contactString);
					}
				}
			}
		}
		return result;
	}
}
